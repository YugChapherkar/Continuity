# Apollo Core Consensus v2.4.1
Operational runbook