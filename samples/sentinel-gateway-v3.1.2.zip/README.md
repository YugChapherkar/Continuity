# Sentinel API & Edge Routing v3.1.2
Envoy-based edge reverse proxy and TLS termination gateway.

## Runbook Commands
./bin/sentinel-ctrl --config /etc/sentinel/config.yaml
curl -s http://127.0.0.1:9901/clusters | grep healthy
