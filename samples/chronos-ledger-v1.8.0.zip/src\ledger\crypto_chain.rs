pub struct AuditBlock {
    pub prev_hash: String,
    pub hash: String,
    pub action: String,
}
