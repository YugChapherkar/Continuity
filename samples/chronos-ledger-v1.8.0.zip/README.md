# Chronos Immutable Audit Ledger v1.8.0
Tamper-evident cryptographically signed audit trail recording every code deployment and handoff.

## Runbook Commands
./bin/chronos-verify --chain /var/data/chronos.ledger --range HEAD~1000..HEAD
