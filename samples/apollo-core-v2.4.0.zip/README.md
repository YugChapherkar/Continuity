# Apollo Core Distributed Consensus v2.4.0
High-throughput Raft state machine and WAL persistence tier.

## Architectural Tenets
- [ADR-041]: Speculative Read Barrier via Monotonic Lease Epochs.
- [ADR-039]: Linux io_uring WAL Flush.

## Runbook Commands
./bin/apollo-ctl status --endpoint http://10.0.1.10:9090
./bin/apollo-verify --cluster-id 0x9F4 --verify-linearizability
