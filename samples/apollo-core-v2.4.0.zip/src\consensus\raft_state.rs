pub struct RaftState {
    pub current_term: u64,
    pub commit_index: u64,
    pub lease_epoch: u64,
}

impl RaftState {
    pub fn assert_read_barrier(&self, clock_skew_ms: u64) -> bool {
        clock_skew_ms <= 5 && self.lease_epoch > 0
    }
}
