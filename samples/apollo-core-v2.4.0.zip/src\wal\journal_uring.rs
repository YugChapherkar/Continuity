pub struct JournalUring {
    pub ring_entries: u32,
    pub fixed_buffers: bool,
}
